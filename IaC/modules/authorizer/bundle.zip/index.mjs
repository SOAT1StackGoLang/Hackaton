import { CognitoJwtVerifier } from "aws-jwt-verify";
import { jwtDecode } from "jwt-decode";
// import { CognitoIdentityProviderClient, GetUserCommand } from "@aws-sdk/client-cognito-identity-provider";

// const client = new CognitoIdentityProviderClient({
//   region: "us-east-1",
//   credentials: {
//     accessKeyId: process.env.ACCESS_KEY_ID,
//     secretAccessKey: process.env.SECRET_ACCESS_KEY,
//   }}
// );

const verifier = CognitoJwtVerifier.create({
  userPoolId: process.env.USER_POOL_ID,
  tokenUse: "access",
  clientId: process.env.CLIENT_ID,
});

export const handler = async (event, ctx, callback) => {
  if (!event.headers.authorization) {
    console.log('Returning not authorized');
    return {
      isAuthorized: false,
    };
  }
  try {    
    console.log('Verifying in cognito');
    await verifier.verify(event.headers.authorization);

    // const input = {
    //   AccessToken: event.headers.authorization,
    // };
  
    // const command = new GetUserCommand(input);
    // const { UserAttributes } = await client.send(command);

    // const uuid = UserAttributes.find(attribute => attribute.Name === 'custom:uuid').Value;
    
    console.log('Returning authorized');
    return {
      isAuthorized: true,
      context: {
        // userId: uuid,
        username: jwtDecode(event.headers.authorization).username
      }
    };
  } catch (e) {
    console.log('Returning not authorized');
    console.error(e);
    return {
      isAuthorized: false,
    };
  }
};